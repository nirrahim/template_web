<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h4 class="text-themecolor">Datatable</h4>
            </div>
            <div class="col-md-7 align-self-center text-right">
                <div class="d-flex justify-content-end align-items-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Data Pasien</li>
                    </ol>
                    <button type="button" class="btn btn-info d-none d-lg-block m-l-15" data-toggle="modal"
                        data-target=".bs-example-modal-lg"><i class="fa fa-plus-circle"></i> Tambah Data</button>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Data Export</h4>
                        <h6 class="card-subtitle">Export data to Copy, CSV, Excel, PDF & Print</h6>
                        <div class="table-responsive m-t-40">
                            <table id="example23" class="display nowrap table table-hover table-striped table-bordered"
                                cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Jenis K</th>

                                        <th>Alamat</th>

                                        <th>Tanggal Lahir</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Jenis K</th>


                                        <th>Alamat</th>
                                        <th>Tanggal Lahir</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php
                                    $no = 0;
                                    foreach ($datapasien as $row):
                                        $no++;
                                    ?>
                                    <tr>
                                        <td> <?php echo $no ?>
                                        </td>
                                        <td>
                                            <?php echo $row->nama_pasien; ?></td>
                                        <td>
                                            <?php echo $row->jenis_k; ?></td>
                                        <td>
                                            <?php echo $row->alamat; ?></td>
                                        <td>
                                            <?php echo $row->tgl_lahir; ?></td>
                                        <td> <a href="#" class="btn btn-info waves-effect text-left" data-toggle="modal"
                                                data-target=".bs-example-modal-lg-edit<?php echo $row->id_pasien; ?>"><i
                                                    class="fa   fa-pencil"></i>
                                                Edit</a> |
                                            <a href="#" class="btn btn-danger waves-effect text-left"
                                                data-toggle="modal"
                                                data-target="#modalhapus<?php echo $row->id_pasien; ?>">
                                                <i class="fa fa-trash-o"></i>
                                                Hapus</a>
                                        </td>
                                    </tr>


                                    <div id="modalhapus<?php echo $row->id_pasien; ?>" class="modal fade" tabindex="-1"
                                        role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="myModalLabel">Hapus Data</h4>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-hidden="true">×</button>
                                                </div>
                                                <form
                                                    action="<?= base_url() ?>pasien/hapus/<?php echo $row->id_pasien; ?>"
                                                    method="post" class="form-material form-horizontal">
                                                    <div class="modal-body">
                                                        <h4>Apakah Anda yakin ingin menghapus data
                                                            <b><?php echo $row->nama_pasien; ?></b> ini?
                                                        </h4>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit"
                                                            class="btn btn-info waves-effect text-left">Hapus</button>

                                                        <button type="button" class="btn btn-danger waves-effect"
                                                            data-dismiss="modal">Batal</button>
                                                    </div>
                                                </form>
                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                                    </div>

                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


                <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog"
                    aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="myLargeModalLabel">Tambah Data Pasien</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            </div>
                            <div class="modal-body">
                                <form action="<?= base_url() ?>pasien/simpan" method="post"
                                    class="form-material form-horizontal">
                                    <div class="form-group">
                                        <label class="col-md-12" for="example-text">Nama</span>
                                        </label>
                                        <div class="col-md-12">
                                            <input type="text" name="nama" class="form-control"
                                                placeholder="enter your name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12" for="bdate">Tanggal Lahir</span>
                                        </label>
                                        <div class="col-md-12">
                                            <input type="date" name="tgllahir" class="form-control mydatepicker"
                                                placeholder="enter your birth date">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-12">Jenis Kelamin</label>
                                        <div class="col-sm-12">
                                            <select class="form-control" name="jenis_k">
                                                <option>Pilih Jenis Kelamin</option>
                                                <option value="laki-laki">Laki - Laki</option>
                                                <option value="perempuan">Perempuan</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-md-12">Alamat</label>
                                        <div class="col-md-12">
                                            <textarea class="form-control" name="alamat" rows="3"></textarea>
                                        </div>
                                    </div>



                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-success waves-effect text-left">Simpan</button>
                                <button type="button" class="btn btn-danger waves-effect text-left"
                                    data-dismiss="modal">Batal</button>
                            </div>
                            </form>

                        </div>
                    </div>
                </div>

                <?php
                $no = 0;
                foreach ($datapasien as $row):
                    $no++;
                ?>
                <div class="modal fade bs-example-modal-lg-edit<?php echo $row->id_pasien; ?>" tabindex="-1"
                    role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="myLargeModalLabel">Edit Data Pasien -
                                    <?php echo $row->nama_pasien; ?></h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            </div>
                            <div class="modal-body">
                                <form action="<?= base_url() ?>pasien/update/<?php echo $row->id_pasien; ?>"
                                    method="post" class="form-material form-horizontal">
                                    <div class="form-group">
                                        <label class="col-md-12" for="example-text">Nama</span>
                                        </label>
                                        <div class="col-md-12">
                                            <input type="text" name="nama" class="form-control"
                                                value="<?php echo $row->nama_pasien; ?>" placeholder="enter your name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12" for="bdate">Tanggal Lahir</span>
                                        </label>
                                        <div class="col-md-12">
                                            <input type="date" name="tgllahir" value="<?php echo $row->tgl_lahir; ?>"
                                                class="form-control mydatepicker" placeholder="enter your birth date">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-12">Jenis Kelamin</label>
                                        <div class="col-sm-12">
                                            <select class="form-control" name="jenis_k">
                                                <option>Pilih Jenis Kelamin</option>
                                                <option value="laki-laki">Laki - Laki</option>
                                                <option value="perempuan">Perempuan</option>
                                            </select>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-md-12">Alamat</label>
                                        <div class="col-md-12">
                                            <textarea class="form-control" name="alamat"
                                                rows="3"><?php echo $row->alamat; ?></textarea>
                                        </div>
                                    </div>



                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-success waves-effect text-left">Update</button>
                                <button type="button" class="btn btn-danger waves-effect text-left"
                                    data-dismiss="modal">Batal</button>
                            </div>
                            </form>

                        </div>
                    </div>
                </div>

                <?php endforeach ?>
            </div>
        </div>

    </div>
</div>