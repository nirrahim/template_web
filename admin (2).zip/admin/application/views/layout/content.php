<?php
if ($conten) {
    $this->load->view($conten);
}
